fun main() {
    println("Kotlin is Awesome!")
}