/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

data class DataVehicle(val type: String, val maxSpeed: Int, val maxTank: Int)

fun main() {

    // TODO 1
    val vehicle = DataVehicle("Motorcycle", 230, 10)


    // TODO 2
    val type = vehicle.component1()
    val maxSpeed = vehicle.component2()
    val maxTank = vehicle.component3()


    // TODO 3
    println("""
        Vehicle
        Type: $type
    """.trimIndent())
    print("Maximal Speed: $maxSpeed")
    println("Km/s")
    print("Maximal Tank: $maxTank")
    print("Ltr")

}