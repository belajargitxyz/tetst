const checklist = [
  "Membangun dan Menjalankan Program Kotlin",
  "Membangun dan Menjalankan Program Kotlin",
  "Kotlin Fundamental",
  "Control Flow",
  "Data Class dan Collections",
  "Functional",
  "Object-Oriented",
  "Generics",
  "Coroutines"
]

const checklistPosition = {
  "Membangun dan Menjalankan Program Kotlin": 0,
  "Kotlin Fundamental": 1,
  "Control Flow": 2,
  "Data Class dan Collections": 3,
  "Functional": 4,
  "Object-Oriented": 5,
  "Generics": 6,
  "Coroutines": 7
}

const validate = submissionData => {
  let providedDataIsValid = true

  if (submissionData == undefined || submissionData == null) {
    providedDataIsValid = false
  }

  submissionData.forEach(submission => {
    if (checklist.includes(submission.checklist) === false) {
      providedDataIsValid = false
    }
  })

  return providedDataIsValid
}

module.exports = { validate, checklistPosition }