const fs = require('fs')


const checklist = [
    "Membangun dan Menjalankan Program Kotlin",
    "Kotlin Fundamental",
    "Control Flow",
    "Data Class dan Collections",
    "Functional",
    "Object-Oriented",
    "Generics",
    "Coroutines"
]

const clearPunctuation = code => {
    const punctuation = /[!"#$%&'()*+,-.\\\/:;<=>?@[\]^_`{|}~\n\t]/g;
    const cleanCode = code.replace(punctuation, " ")
    const clean = cleanCode.split(' ').filter(item => {
        return item != ""
    }).join(' ')
 
    return clearUnsedWord(clean).trim()
}

const clearUnsedWord = code => {
    return code.replace('Untuk menyelesaikan tugas latihan Anda tidak diperbolehkan mengubah struktur kode yang sudah ada Kecuali Untuk melakukan improvisasi kode Mengikuti perintah yang ada Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan', '')
}

module.exports = function mapper(submissionFilePaths) {
    return checklist.map(check => {
        const path = submissionFilePaths.filter(path => path.includes(check))[0]
        try {
            const data = fs.readFileSync(path, 'utf8')
            return { checklist: check, code: clearPunctuation(data) }
        } catch (error) {
            return { checklist: check, code: 'fun main()' }
        }
    })
}