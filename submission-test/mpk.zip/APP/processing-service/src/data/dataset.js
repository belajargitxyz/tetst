const fs = require('fs');
const Path = require('path');

const dataset = () => {
    const path = Path.resolve(process.env.SUBMISSION_DATASET)
    const data = fs.readFileSync(path, { encoding: 'utf8', flag: 'r' });
    return JSON.parse(data)
}

module.exports = dataset