const { createClient } = require('@supabase/supabase-js')
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY)

const saveToken = async (username, token) => {
    const { data, error } = await supabase
        .from(process.env.SUPABASE_TOKEN_TABLE)
        .insert([
            { username, token },
        ])

    if (error) return { success: false, message: error.message }

    return { success: true, data }
}

const checkTokenIfAvailble = async (token) => {
    let { data: TOKEN } = await supabase
        .from(process.env.SUPABASE_TOKEN_TABLE)
        .select('*')
        .like('token', token)

    if (TOKEN.length < 1) return { success: false, message: "Request token not found" }

    const availableToken = TOKEN[0]
    if (!availableToken.verified) return { success: false, message: "Fail to procced unverified token" }

    return { success: true }
}

const LOG = async (type, message) => {
    await supabase
        .from(process.env.SUPABASE_LOG_TABLE)
        .insert([
            { type, message },
        ])
}

module.exports = { checkTokenIfAvailble, saveToken, LOG }