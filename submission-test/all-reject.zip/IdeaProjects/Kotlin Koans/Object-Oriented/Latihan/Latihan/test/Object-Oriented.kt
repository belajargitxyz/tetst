class Cat(private val name: String) {
    // TODO 1
    var sleep: Boolean = false
        get() {
            println("Omeng dipanggil")
            return field
        }
        set(value) {
            println("Omeng dipanggil")
            field = value
        }

    fun toSleep() {
        if (sleep) println("$name, let's sleep!") else println("$name, let's play!")
    }
}

fun main() {

    // TODO 2
    val omeng = Cat("Omeng")

    omeng.toSleep()
    omeng.sleep = true
    omeng.toSleep()
}