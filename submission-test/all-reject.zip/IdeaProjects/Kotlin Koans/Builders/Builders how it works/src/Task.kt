import Answer.*

enum class Answer { a, b, c }

val answers = mapOf<Int, Answer?>(
        1 to null, 2 to null, 3 to null, 4 to null
)
