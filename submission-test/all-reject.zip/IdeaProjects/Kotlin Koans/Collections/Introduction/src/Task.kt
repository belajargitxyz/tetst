fun Shop.getSetOfCustomers(): Set<Customer> =
        TODO()
