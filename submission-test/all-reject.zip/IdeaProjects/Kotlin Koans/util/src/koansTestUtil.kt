package koans.util

fun errorMessage(functionName: String) =
        "The function '$functionName' is implemented incorrectly\n"