fun main() {
    val pertama = 22
    val kedua = 32
    val ketiga = 49
    val ResultA = pertama + kedua
    val ResultB = ResultA + ketiga
    println("ResultA is "+ ResultA)
    println("ResultA is "+ ResultB)}