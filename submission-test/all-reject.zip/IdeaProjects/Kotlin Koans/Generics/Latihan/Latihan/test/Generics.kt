fun main() {
    val stringResult = getResult("Kotlin")
    val intResult = getResult(100)


    println("String result: $stringResult\n" +
            "Int result: $intResult")
}


fun <T> getResult(args: T): Int {
    return when(args){
        is Int -> args * 3
        is String -> args.length
        else -> 0
    }
}