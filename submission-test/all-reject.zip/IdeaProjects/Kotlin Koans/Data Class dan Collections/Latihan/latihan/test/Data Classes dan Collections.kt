fun main()
{
     val vehicle = mapOf<String, String>(
        "type" to "Car",
        "maxSpeed" to "699Km/s",
        "maxTank" to "99Ltr",
        "maxCap" to "8")
    val type = vehicle["type"]
    val maxSpeed =  vehicle["maxSpeed"]
    val maxTank =  vehicle["maxTank"]
    val maxCap= vehicle["maxCap"]

    println("Vehicle")
    println("Type         : $type")
    println("Max Speed    : $maxSpeed")
    println("Max Tank     : $maxTank")
    println("Max Capacity : $maxCap")
}