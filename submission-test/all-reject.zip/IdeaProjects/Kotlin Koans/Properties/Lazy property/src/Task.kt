class LazyProperty(val initializer: () -> Int) {
    /* TODO */
    val lazy: Int
        get() {
            TODO()
        }
}
