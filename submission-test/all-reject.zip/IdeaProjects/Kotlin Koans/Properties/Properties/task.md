## Properties

Learn about the [properties](http://kotlinlang.org/docs/reference/properties.html#properties-and-fields) in Kotlin.

Add a custom setter to PropertyExample.propertyWithCounter so that
the `counter` property is incremented every time a `propertyWithCounter` is assigned to it.
