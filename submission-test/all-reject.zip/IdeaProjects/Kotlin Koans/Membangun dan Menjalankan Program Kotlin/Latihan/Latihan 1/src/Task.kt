fun main() {
    val name = "SMD"

    print("Hello my name is ")
    println(name)
    print(if (true) "Always true" else "Always false")
}
