package org.kotlinlang.play
fun main() {
    println("Kotlin is Awesome!")
}