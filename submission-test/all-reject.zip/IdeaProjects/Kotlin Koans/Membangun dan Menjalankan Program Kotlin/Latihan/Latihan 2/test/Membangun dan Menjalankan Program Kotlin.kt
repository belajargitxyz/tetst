package org.kotlinlang.play
fun main() {
    println("Kotlin,")
    println("is Awesome!")
}