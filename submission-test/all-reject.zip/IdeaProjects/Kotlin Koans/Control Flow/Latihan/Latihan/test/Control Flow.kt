fun main(args: Array<String>) {
    val list = listOf(11, 39, 75, 119, 171, 231, 299, 375)
    for (i in list) println("range result is "+i)
}