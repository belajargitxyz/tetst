fun main(args : Array<String>) {
    println("Kotlin,")
    println("is Awesome!")
}