const jwt = require('jsonwebtoken');
const { checkTokenIfAvailble, saveToken } = require('../data/supabase')

async function save(req, res, next) {
    const username = req.body.username
    const token = jwt.sign({ name: username }, process.env.JWT_SECRET, { expiresIn: '1y' });

    const result = await saveToken(username, token)
    if (!result.success) return res.status(403).json({ status: 'failed', message: result.message })

    req.data = result.data
    next()
}

async function auth(req, res, next) {
    const token = req.headers['authorization']

    if (token == null) return res.status(401).json({ status: 'failed', message: 'Unauthorized request!' })

    const tokenIsAvailable = await checkTokenIfAvailble(token)
    if (!tokenIsAvailable.success) return res.status(401).json({ status: 'failed', message: tokenIsAvailable.message })

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ status: 'failed', message: 'Forbidden request token' })
        req.user = user
        next()
    })
}

module.exports = { auth, save }