'use strict'

const { auth, save } = require('./middleware')
const { LOG } = require('./data/supabase')

const amqp = require('amqplib');
let submissionChannel
const init = async () => {
    try {
        const rabbitURL = `amqp://${process.env.RABBIT_USERNAME}:${process.env.RABBIT_PASSWORD}@${process.env.RABBIT_HOST}:${process.env.RABBIT_PORT}/${process.env.RABBIT_VIRTUAL_HOST}`
        const connection = await amqp.connect(rabbitURL);
        submissionChannel = await connection.createChannel();
        await submissionChannel.assertQueue(process.env.RABBIT_QUEUE_CHANNEL, {
            durable: true,
        });
    } catch (error) {
        LOG('ERROR', error)
    }
};

init();

const express = require('express');
const app = express();
app.use(express.json())

app.post('/api/compare', auth, async function (req, res) {
    try {
        await submissionChannel.sendToQueue(process.env.RABBIT_QUEUE_CHANNEL, Buffer.from(JSON.stringify(req.body)))
        res.json({ status: "success", message: 'Submission on process, be patient!' });
    } catch (error) {
        LOG('ERROR', error)
        res.json({ status: "failed", message: error });
    }
});

app.post('/api/generate/token/', save, function (req, res) {
    return res.json({ status: 'success', data: req.data })
});

app.get('/api/publish', function (req, res) {
    console.log('execute publish!');
    res.json({ status: "success", message: 'Submission executed!' });
});

app.listen(9001, function () {
    LOG('INFO', this)
});