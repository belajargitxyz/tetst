const axios = require('axios').default;

const executeDownloadSubmission = async (submissionId) => {
    try {
        const params = new URLSearchParams()
        params.append('app_secret', process.env.APP_SECRET)
        params.append('app_key', process.env.APP_KEY)

        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }

        const tokenResponse = await axios.post(process.env.TOKEN_ENDPOINT, params, config)
        const token = `Bearer ${tokenResponse.data.access_token}`
        return axios.get(process.env.DOWNLOAD_SUBMISSION_ENDPOINT + `${submissionId}`, {
            headers: {
                'X-Authorization': token
            },
            responseType: 'stream'
        })
    } catch (error) {
        console.log(error.message);
        return null
    }
}

const publishApprovedSubmission = async (data) => {
    try {
        const params = new URLSearchParams()
        params.append('app_secret', process.env.APP_SECRET)
        params.append('app_key', process.env.APP_KEY)

        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }

        const tokenResponse = await axios.post(process.env.TOKEN_ENDPOINT, params, config)
        const token = `Bearer ${tokenResponse.data.access_token}`
        return axios.get(process.env.APPROVED_ENDPOINT + `${submissionId}`, {
            headers: {
                'X-Authorization': token
            },
            data
        })
    } catch (error) {
        return null
    }
}

const publishRejectedSubmission = async (data) => {
    try {
        const params = new URLSearchParams()
        params.append('app_secret', process.env.APP_SECRET)
        params.append('app_key', process.env.APP_KEY)

        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }

        const tokenResponse = await axios.post(process.env.TOKEN_ENDPOINT, params, config)
        const token = `Bearer ${tokenResponse.data.access_token}`
        return axios.get(process.env.REJECTED_ENDPOINT + `${submissionId}`, {
            headers: {
                'X-Authorization': token
            },
            data
        })
    } catch (error) {
        return null
    }
}

module.exports = { executeDownloadSubmission, publishApprovedSubmission, publishRejectedSubmission }