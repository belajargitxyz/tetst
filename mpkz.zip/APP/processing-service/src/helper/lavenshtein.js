const levenshtein = require('js-levenshtein');

const similarity = (actual, expect) => {
  var longer = actual
  var shorter = expect
  if (actual.length < expect.length) {
    longer = expect
    shorter = actual
  }

  const longerLength = longer.length
  if (longerLength == 0){
    return 1.0
  }

  return (longerLength - levenshtein(longer, shorter)) / longerLength
}

module.exports = similarity