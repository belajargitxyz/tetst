const similarity = require('./lavenshtein')

const getHighScoreOfSimilarity = (code, dataset) => {
  const temp = []
  dataset.forEach(data => {
    temp.push({
      source: code,
      compareWith: data.code,
      sentiment: data.sentiment,
      score: similarity(code, data.code)
    })
  })

  return temp.reduce((left, right) => left.score > right.score ? left : right);
}

module.exports = getHighScoreOfSimilarity