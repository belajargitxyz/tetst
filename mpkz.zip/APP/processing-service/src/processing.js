'use strict'

const checklistPosition = {
    "Membangun dan Menjalankan Program Kotlin": 0,
    "Kotlin Fundamental": 1,
    "Control Flow": 2,
    "Data Class dan Collections": 3,
    "Functional": 4,
    "Object-Oriented": 5,
    "Generics": 6,
    "Coroutines": 7
}

const amqp = require('amqplib');
const Path = require('path');
const Fs = require('fs');
const glob = require("glob");
const extract = require('extract-zip');

const getHighScoreOfSimilarity = require('./helper/scores')

const LOG = require('./data/supabase');
const { dataset, rejectionTemplate } = require('./data/dataset');
const { executeDownloadSubmission, publishApprovedSubmission, publishRejectedSubmission } = require('./network/networking');
const mapper = require('./helper/mapper')

const execute = async () => {

    try {
        const rabbitURL = `amqp://${process.env.RABBIT_USERNAME}:${process.env.RABBIT_PASSWORD}@${process.env.RABBIT_HOST}:${process.env.RABBIT_PORT}/${process.env.RABBIT_VIRTUAL_HOST}`
        const connection = await amqp.connect(rabbitURL);
        const submissionChannel = await connection.createChannel();
        await submissionChannel.assertQueue(process.env.RABBIT_QUEUE_CHANNEL, {
            durable: true,
        });

        submissionChannel.consume(process.env.RABBIT_QUEUE_CHANNEL, async (message) => {
            try {
                const data = JSON.parse(message.content.toString())

                const downloadedFilePath = Path.resolve(process.env.TEMP_DOWNLOADED_FILE, `${data.submission_id}.zip`)
                const extractTargetFilePath = Path.resolve(process.env.TEMP_EXTRACTED_SUBMISSION, `${data.submission_id}`)
                const writer = Fs.createWriteStream(downloadedFilePath)

                const response = await executeDownloadSubmission(data.submission_id)
                response.data.pipe(writer)
                writer.on('finish', async () => {
                    try {
                        await extract(downloadedFilePath, { dir: extractTargetFilePath })

                        console.log('Proccessing');

                        glob(extractTargetFilePath + '/**/*', (error, result) => {
                            if (error) return LOG('ERROR', error)

                            const taskFile = result.filter(file => file.endsWith('.kt') && file.includes('Task'))
                            const submissonDataClean = mapper(taskFile)
                            const submissionCompareResult = submissonDataClean.map(data => {
                                const highSimilarity = getHighScoreOfSimilarity(data.code, dataset())
                                return {
                                    checklist: data.checklist,
                                    sentiment_used: highSimilarity.sentiment,
                                    sentiment_score: highSimilarity.score,
                                    approved: highSimilarity.sentiment.includes("approved"),
                                }
                            })

                            const submissionIsApproved = submissionCompareResult.filter(result => result.approved === false).length === 0
                            const rejectedChecklistMessage = submissionCompareResult.filter(result => result.approved === false).map(result => result.checklist).join(', ').replace(/, ([^,]*)$/, ' dan $1')
                            const approvedChecklistPosition = submissionCompareResult.filter(result => result.approved === true).map(result => checklistPosition[result.checklist]).filter(result => result != null)

                            if (submissionIsApproved) {
                                const submissionResult = {
                                    submission_id: data.submission_id,
                                }

                                LOG('INFO', submissionResult)
                            } else {
                                const feedback = rejectedChecklistMessage !== "" ? rejectionTemplate().feedback.replace('{{ checklist }}', rejectedChecklistMessage) : null
                                const submissionResult = {
                                    submission_id: data.submission_id,
                                    reviewer_comment: rejectionTemplate().template.replace('{{ feedback }}', feedback),
                                    completed_checklists: [...new Set(approvedChecklistPosition)]
                                }

                                LOG('INFO', submissionResult)
                            }

                            Fs.rmSync(downloadedFilePath)
                            Fs.rmdirSync(extractTargetFilePath, { recursive: true })
                        })
                    } catch (error) {
                        console.log("PROC:" + error);
                        LOG('ERROR', error.toString())
                    }
                })
            } catch (error) {
                LOG('ERROR', error.toString())
            }

        }, { noAck: true });
    } catch (error) {
        LOG('ERROR', error.toString())
    }
};

execute()