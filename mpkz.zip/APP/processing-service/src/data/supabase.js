const { createClient } = require('@supabase/supabase-js')
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY)

const LOG = async (type, message) => {
    if (process.env.NODE_ENV === 'debug') {
        console.log({ type, message });
    }
    await supabase
        .from(process.env.SUPABASE_LOG_TABLE)
        .insert({ type, message })
}

module.exports = LOG